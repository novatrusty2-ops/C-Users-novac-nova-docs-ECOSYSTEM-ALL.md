# PouchPay Android — callData fix pack (31.195 / 31195)

Router callData is fixed on the **production bridge**. This zip is the Android drop-in config for build **31.195**.

> This repository does **not** contain the Play Store APK source for `global.alltra.app`.  
> Use this pack to point your Android build at the fixed quote/routes APIs (or ship as remote config).

## Live endpoints (HTTP 200 + callData)

| Key | URL |
|-----|-----|
| Bridge | https://pouchpay-bridge-production-f56f.up.railway.app |
| Quote | https://pouchpay-bridge-production-f56f.up.railway.app/v0/quote |
| Routes | https://pouchpay-bridge-production-f56f.up.railway.app/v1/advanced/routes |
| Tokens | https://pouchpay-bridge-production-f56f.up.railway.app/v1/tokens |
| CMC | https://pouchpay-bridge-production-f56f.up.railway.app/v1/cmc |

**Do not** use `https://api.pouchpay.io/v0/quote` for swaps — it still returns empty `path[]` and no `callData`.

## Android version stamps

- `versionName` / `appVersion` / `liveBuild`: **31.195**
- `versionCode`: **31195**
- Package: `global.alltra.app`

## Apply in your Android project

1. Copy `config/PouchPayEndpoints.kt` into the app module (or merge URLs into your existing API client).
2. Or paste `config/BuildConfig.snippet.gradle` into `android/app/build.gradle` `defaultConfig`.
3. Or load `config/pouchpay-android-production.json` as remote/local config and set:
   - `quoteApi`
   - `routesApi`
4. Ensure the swap executor **requires** non-empty `path` + `callData` / `transactionRequest.data` before signing.
5. Bump to `versionName "31.195"` and `versionCode 31195`, rebuild/sign the APK/AAB.

## Verify (included)

See `verify/`:

- `health.json` — green, `appVersion: 31.195`
- `quote-AUSDT-ETH.json` — WALL hop + UniswapV2 `callData`
- `quote-ZARA-BNB.json` — external wrap
- `quote-USDT-TRC20-TRX.json` — external TRC20 → TRX

## Backend patch (optional)

`patch/pouchpay-calldata` — Nest module to embed the same callData builder on Bank / `api.pouchpay.io` hosts.

## Router

`0xEd04ee8307C0656207af5afe3926Ae2380052940` on Alltra `651940`.
