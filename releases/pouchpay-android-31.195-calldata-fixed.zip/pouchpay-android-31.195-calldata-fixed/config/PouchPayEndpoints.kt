package global.alltra.app.config

/** Fixed callData production endpoints — PouchPay Android 31.195 / 31195 */
object PouchPayEndpoints {
    const val APP_VERSION = "31.195"
    const val VERSION_CODE = 31195
    const val BRIDGE_URL = "https://pouchpay-bridge-production-f56f.up.railway.app"
    const val QUOTE_API = "$BRIDGE_URL/v0/quote"
    const val ROUTES_API = "$BRIDGE_URL/v1/advanced/routes"
    const val TOKENS_API = "$BRIDGE_URL/v1/tokens"
    const val CMC_API = "$BRIDGE_URL/v1/cmc"
    const val ROUTER = "0xEd04ee8307C0656207af5afe3926Ae2380052940"
    const val CHAIN_ID = 651940L
    const val REQUIRE_CALLDATA = true
}
